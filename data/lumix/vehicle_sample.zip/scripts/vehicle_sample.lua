local forward = 0
local backward = 0
local left = 0
local right = 0

function update()
    this.vehicle:setAccel(forward + backward)
    this.vehicle:setSteer(left + right)
end

function onInputEvent(event : InputEvent)
	if event.type == "button" then
		if event.device.type == "keyboard" then
			if event.key_id == string.byte("W") then
                if event.down then forward = -1
                else forward = 0 end
			end
			if event.key_id == string.byte("S") then
                if event.down then backward = 1
                else backward = 0 end
			end
			if event.key_id == string.byte("A") then
                if event.down then left = 1
                else left = 0 end
			end
			if event.key_id == string.byte("D") then
                if event.down then right = -1
                else right = 0 end
			end
		end		
	end
end